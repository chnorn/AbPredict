rm -r top_20
mkdir top_20

for i in $(cat in/sequences.txt | awk '{print $1}' | awk 'substr($0,1,1)!="#"'); do
	# best_E_plus_five=$(grep $i rmsd_file.txt | sort -nk 2 | head -1 | awk '{print $2+5}')
	# grep $i rmsd_file.txt | awk '$2<'$best_E_plus_five'' | awk '{system("cp "$1" top_20/")}'	
	grep $i rmsd_file.txt | sort -nk 2 | head -20 | awk '{system("cp "$1" top_20/")}'
done
