rm -r best_clusters

mkdir best_clusters

cat best_clusters.txt | awk '{system("cp pdb/"$NF" best_clusters")}'

