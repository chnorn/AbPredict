__author__ = 'christoffernorn'

# Import various including PyMOL
#import __main__
#__main__.pymol_argv = ['pymol','-qck'] # Pymol: quiet and no GUI
#import pymol
from pymol import cmd
from pymol import stored
#pymol.finish_launching()
import glob




# Functions
def find_nearest_res_to_atom(target_name, source_name, source_res, aa_name='ca'):
    """ This function finds the nearest residue to source_residue from
    a list of target residues. Defaults to look at ca atoms but this behavoir
    can be changed using aa_name"""

    stored.target_residues=[]
    cmd.iterate('('+target_name+' and name ca)','stored.target_residues.append(resi)')
    min_dist = 1000000
    nearest_res = 'NONE'
    for res_no in stored.target_residues:
        try:
            distance = cmd.get_distance(target_name+' and resi '+res_no+' and name '+aa_name,
                                    source_name+' and resi '+source_res+' and name '+aa_name)
            if distance < min_dist:
                min_dist = distance
                nearest_res = res_no
        except:
            pass
    return nearest_res



# Load native and native positions
def make_annotation_file_for_all(native_file, native_residues, target_list, outfile_name):
    """ This function find and create files for all pdbs in target_list, which has
    residues as the same positions (specified in 'native_residues') as the native_file."""
    source_residues = []
    f_open = open(native_residues,'r')
    for line in f_open:
        source_residues = line.split()[1:]
    #print source_residues
    for pdb in target_list:
        print "working on "+pdb
        cmd.reinitialize()
        cmd.load(native_file)
        cmd.load(pdb)
        source_pdb_name = native_file.replace('/',' ').split()[-1][:-4]
        target_pdb_name = pdb.replace('/',' ').split()[-1][:-4]
        cmd.align(target_pdb_name,source_pdb_name)
        nearest_residue_list = []

        write = True
        for residue in source_residues:
            # From which coordinate
            nearest = find_nearest_res_to_atom(target_pdb_name, source_pdb_name, residue)
            if nearest == -1:
                write = False
            nearest_residue_list.append(nearest)
        #print ' '.join(nearest_residue_list)
        test_string = target_pdb_name+" "+' '.join(nearest_residue_list)+'\n'
        print test_string
        if write:
            with open(outfile_name, 'a') as outfile:
                outfile.write(test_string)


# Identify target files
kappa_files_path = []
lambda_files_path = []
with open('../in/sequences.txt','r') as f_open:
	for line in f_open:
		abName = line.split()[0]
                if abName.startswith('#'):
                        continue
		if line.split()[-1] == 'kappa':
			kappa_files_path.append('../vL_vH_natives/'+abName+'.pdb')
		if line.split()[-1] == 'lambda':
			lambda_files_path.append('../vL_vH_natives/'+abName+'.pdb')


# Make annotation for heavy chains
target_list = kappa_files_path + lambda_files_path
make_annotation_file_for_all('data/templates/1AHW_vH.pdb','data/templates/1AHW_vH_annotation_CDRs.txt',target_list,'vH_annotation_CDRs.txt')
make_annotation_file_for_all('data/templates/1AHW_vH.pdb','data/templates/1AWH_vH_annotation_cores.txt',target_list,'vH_annotation_cores.txt')

# Make annotation for light chain kappa
target_list = kappa_files_path
make_annotation_file_for_all('data/templates/1AHW_vL.pdb','data/templates/1AHW_vL_annotation_CDRs.txt',target_list,'vL_annotation_CDRs.txt')
make_annotation_file_for_all('data/templates/1AHW_vL.pdb','data/templates/1AHW_vL_annotation_cores.txt',target_list,'vL_annotation_cores.txt')

# Makes annotation for light chain lambda
target_list = lambda_files_path
make_annotation_file_for_all('data/templates/2G75_vL.pdb','data/templates/2G75_vL_annotation_CDRs.txt',target_list,'vL_annotation_CDRs.txt')
make_annotation_file_for_all('data/templates/2G75_vL.pdb','data/templates/2G75_vL_annotation_cores.txt',target_list,'vL_annotation_cores.txt')

