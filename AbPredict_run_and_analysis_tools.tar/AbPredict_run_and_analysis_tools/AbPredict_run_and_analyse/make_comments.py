#!/usr/bin/python2.7
# Description:	Determines which antibody segments, that will be appropriate for a given sequence
# Usage: 		make_comments.py -H VHLQQSGAELMKPGASVKISCKASGYTFITYWIEWVKQRPGHGLEWIGDILPGSGSTNYNENFKGKATFTADSSSNTAYMQLSSLTSEDSAVYYCARSGYYGNSGFAYWGQGTLVTVS -L DIVMTQSPSSLTVTAGEKVTMSCKSSQSLLSSGNQKNYLTWYQQIPGQPPKLLIYWASTRESGVPDRFTGSGSGTDFTLTINSVQAEDLAVYYCQNDYTYPLTFGAGTKLE
# Requirements:	torsion_db/H1_H2.db torsion_db/H3.db torsion_db/L1_L2.db torsion_db/L3.db
# Date: 		24/07/14
# Author: 		Christoffer Norn

# from optparse import OptionParser
import sys
import re
import random

# # ----------------------------
# # Input file locations
# # ----------------------------
# torsion_db_folder = 'torsion_db/'
# 
# # ----------------------------
# # Read input from command line
# # ----------------------------
# parser = OptionParser(usage="usage: %prog [options] FILE", version="0.1")
# parser.add_option("-n", "--abName", type="string", dest="abName", metavar="STR", help="Arbitrary antibody name")
# parser.add_option("-L", "--vL_Sequence", type="string", dest="vlSeq", metavar="STR", help="input sequence for vl")
# parser.add_option("-H", "--vH_Sequence", type="string", dest="vhSeq", metavar="STR", help="input sequence for vh")
# parser.add_option("-c", action="store_false", dest="CanonicalEnding", default=True, help="antibody has a non-canonical ending for vl/vh c-term")
# parser.add_option("-t", type="string", dest="lightChainType", default='kappa', help="is it a kappa or lambda light chain?")
# parser.add_option("-p", "--printFormat", type="string", dest="printFormat", metavar="STR", help="Print as pdbComments or as constructInfo")
# 
# 
# (opts, args) = parser.parse_args()
# parser.set_defaults(vlSeq='',vhSeq='',lightChainType='kappa', abName='unnamed', printFormat='pdbComments')
# 

# ----------------------------
# Functions
# ----------------------------

def kappa_chain_specific_sanity_check(vlSequence,vhSequence,isSegmentEndingCanonical):
	vl_n_tail_length = determine_segment_lengths(vlSequence)[0]
	if vl_n_tail_length != 20:
		print "USER INPUT ERROR: The n-tail length of the light chain, (XXX)CXXXCXXX, should be 22aa long. Exiting..."
		sys.exit()
		
	# This test that the last 5 amino acids in the light chain have the expected identities
	if isSegmentEndingCanonical == True:
		vl_nterm_allowances = [(-4,'G'),(-3,'ST'),(-2,'QERK'),(-1,'ILMV')]
		for (position,allowed_identities) in vl_nterm_allowances:
			if vlSequence[position] not in allowed_identities:
				print """USER INPUT ERROR: I expect that the light chain should end with (G) (S/T) (Q/E/K/R) (I/L/M/V) (Q/E/G/T/V). Your light chain
				is ending with '"""+ vlSequence[-5:] +"""'. If you are damn sure that you light chain is supposed to have a non-canonical ending use the flag
				--nonCanonicalEnd to avoid this check. Exiting..."""
				sys.exit()
	
def lambda_chain_specific_sanity_check(vlSequence,vhSequence,isSegmentEndingCanonical):
	vl_n_tail_length = determine_segment_lengths(vlSequence)[0]
	if vl_n_tail_length != 19:
		print "USER INPUT ERROR: The n-tail length of the light chain, (XXX)CXXXCXXX, should be 22aa long. Exiting..."
		sys.exit()
	
	# This test that the last 4 amino acids in the light and the heavy chain have the expected identities
	if isSegmentEndingCanonical == True:
		vl_nterm_allowances = [(-4,'G'),(-3,'ST'),(-2,'KRQDTMA'),(-1,'LIV')]
		for (position,allowed_identities) in vl_nterm_allowances:
			if vlSequence[position] not in allowed_identities:
				print """USER INPUT ERROR: I expect that the light chain should end with (G) (S/T) (Q/E/K) (I/L/M/V) (Q/E/G/T/V). Your light chain
				is ending with '"""+ vlSequence[-5:] +"""'. If you are damn sure that you light chain is supposed to have a non-canonical ending use the flag
				--nonCanonicalEnd to avoid this check. Exiting..."""
				sys.exit()

def input_sanity_check(vlSequence,vhSequence, lightChainType, isSegmentEndingCanonical):
	try: 
		len(vlSequence) == 0
	except:
		print "USER INPUT ERROR: You must supply a sequence for vl. Exiting..."
		sys.exit()
	
	try:
		len(vhSequence) == 0
	except:
		print "USER INPUT ERROR: You must supply a sequence for vh. Exiting..."
		sys.exit()
	
	if vlSequence.count('C') != vhSequence.count('C') and vhSequence.count('C') != 2:
		print "USER INPUT ERROR: You must exactly two cysteines in each chain. Exiting..."
		sys.exit() 
	
	vh_n_tail_length = determine_segment_lengths(vhSequence)[0]
	if vh_n_tail_length != 20:
		print "USER INPUT ERROR: The n-tail length of the heavy chain, (XXX)CXXXCXXX, should be 20aa long. Exiting..."
		sys.exit()
	
	# This test that the last 5 amino acids in the heavy chain have the expected identities
	if isSegmentEndingCanonical == True:
		vh_nterm_allowances = [(-5,'LMST'),(-4,'ILTV'),(-3,'ST'),(-2,'IV'),(-1,'S')]
		for (position,allowed_identities) in vh_nterm_allowances:
			if vhSequence[position] not in allowed_identities:
				print """USER INPUT ERROR: I expect that the light chain should end with (L/M/S/T) (I/L/T/V) (S/T) (I/V) (S). Your light chain
				is ending with '"""+ vhSequence[-5:] +"""'. If you are damn sure that you light chain is supposed to have a non-canonical ending use the flag
				-c to avoid this check. Exiting..."""
				sys.exit()
	
	if lightChainType == 'kappa':
		kappa_chain_specific_sanity_check(vlSequence,vhSequence,isSegmentEndingCanonical)
	elif lightChainType == 'lambda':
		lambda_chain_specific_sanity_check(vlSequence,vhSequence,isSegmentEndingCanonical)
	else:
		print "This shouldn't happen. Why is no lightChainType specified?!?"
		sys.exit()
	
def determine_segment_lengths(vxSequence):
	cys_positions = [i.start() for i in re.finditer('C', vxSequence)]
	n_tail_len = cys_positions[0] 								# (XXX) C  XXX  C  XXX
	CDR1_CDR2_len = cys_positions[1] - cys_positions[0] - 1		#  XXX  C (XXX) C  XXX
	CDR3_c_tail_len = len(vxSequence) - cys_positions[1] - 1 	#  XXX  C  XXX  C (XXX)
	return (n_tail_len, CDR1_CDR2_len, CDR3_c_tail_len)

def read_torsion_db_files(torsionDbFolderPath):
	torsion_db_dict = {'L1_L2':{},'L3':{},'H1_H2':{},'H3':{}}
	for torsion_db in torsion_db_dict.keys():
		f_open = open(torsionDbFolderPath+torsion_db+'.db','r')
		for torsion_entry in f_open:
			try:
				torsion_entry_list = torsion_entry.split()
				entry_name = torsion_entry_list[-2]
				entry_aa = torsion_entry_list[3::4][:-1]
			except:
				print "Tried to parse this line in "+torsionDbFolderPath+torsion_db+'.db:'
				print torsion_entry
				print "Does that look right to you? Not to me..."
			#print entry_name,torsion_entry_list
			#print entry_aa
			try:
				entry_length = [i for i, x in enumerate(entry_aa) if '*' in x][0]
			except:
				print "Tried to find the length of an entry in your " + torsionDbFolderPath + torsion_db + '.db'+ " torsion database, by looking for the first '*' character"
				print "... and failed. This typically means that there is a problem with your torsion database!!"
				print "Does this line look right to you?"
				print torsion_entry
				print "It doesn't look right to me. Exiting..."
				sys.exit()
			if entry_length not in torsion_db_dict[torsion_db]:
				torsion_db_dict[torsion_db][entry_length] = []
			torsion_db_dict[torsion_db][entry_length].append(entry_name)
	return torsion_db_dict

def output_segment_info(torsion_db_dict,vl_CDR1_CDR2_len,vl_CDR3_c_tail_len,vh_CDR1_CDR2_len,vh_CDR3_c_tail_len,abName,printFormat,lightChainType):
	iter_list = [('H1_H2',vh_CDR1_CDR2_len),('H3',vh_CDR3_c_tail_len),('L1_L2',vl_CDR1_CDR2_len),('L3',vl_CDR3_c_tail_len)]
	
	for (segment,segment_len) in iter_list:
		try:
			len(torsion_db_dict[segment][segment_len])
		except:
			print torsion_db_dict[segment]
			print 'Looking for '+segment+' segment with length '+str(segment_len)+' in torsion_db_dict[segment] (above) for '+abName
			print 'ERROR: Could find an appropriate segment for '+segment+'. Exiting...'
			sys.exit()
	
	if printFormat=='pdbComments':
		print 'The comment section could contain:'
		print '##Begin comments##'
		for (segment,segment_len) in iter_list:
			print 'segment_' + segment + ' ' + random.choice(torsion_db_dict[segment][segment_len])
		print '##End comments##'
	if printFormat=='constructInfo':
		#print "name H1_H2 H3 L1_L2 L3"
		print abName,
		for (segment,segment_len) in iter_list:
			print random.choice(torsion_db_dict[segment][segment_len]),
		print lightChainType
	if printFormat == 'returnList':
		vH_H3_vL_L3_list = []
		for (segment,segment_len) in iter_list:
			vH_H3_vL_L3_list.append(random.choice(torsion_db_dict[segment][segment_len]))
		return vH_H3_vL_L3_list
	if printFormat == 'returnAllIn4Lists':
                return torsion_db_dict['H1_H2'][vh_CDR1_CDR2_len], torsion_db_dict['H3'][vh_CDR3_c_tail_len], torsion_db_dict['L1_L2'][vl_CDR1_CDR2_len], torsion_db_dict['L3'][vl_CDR3_c_tail_len]	

# ----------------------------
# MAIN
# ----------------------------
# input_sanity_check( opts.vlSeq , opts.vhSeq , opts.lightChainType )
# 
# if opts.lightChainType == 'kappa':
# 	torsion_db_dict = read_torsion_db_files( 'torsion_db_kappa' )
# elif opts.lightChainType == 'lambda':
# 	torsion_db_dict = read_torsion_db_files( 'torsion_db_lambda' )
# 
# (vl_n_tail_len, vl_CDR1_CDR2_len, vl_CDR3_c_tail_len) = determine_segment_lengths(opts.vlSeq)
# (vh_n_tail_len, vh_CDR1_CDR2_len, vh_CDR3_c_tail_len) = determine_segment_lengths(opts.vhSeq)
# output_segment_info(torsion_db_dict,vl_CDR1_CDR2_len,vl_CDR3_c_tail_len,vh_CDR1_CDR2_len,vh_CDR3_c_tail_len,opts.abName,opts.printFormat,opts.lightChainType)

