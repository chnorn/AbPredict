#!/bin/sh

#produces one pair of files, commandline and jobname. Commandline is used to execute jobname through lsf on the fleishman queue.
#USAGE: for i in *.pdb; do fleish_sub.sh -s ${i} @flags; done

dir=`pwd`
date=`date +%s%N | awk '{printf "%x\n", substr($0,9,length($0)-11)}' `
jobname=${dir}/job/job."${date}"
commandname=${dir}/command
out=${dir}/out/out."${date}"
err=${dir}/err/err."${date}"

echo "#!/bin/bash" > $jobname
#echo ". /usr/share/lsf/conf/profile.lsf" >> $jobname

echo "cd $dir">> $jobname
#printf "/home/labs/fleishman/norn/my_ros/bin/rosetta_scripts.graphics.linuxgccrelease " >> $jobname
printf "/home/labs/fleishman/norn/my_ros/bin/rosetta_scripts.default.linuxgccrelease " >> $jobname
#printf "/home/labs/fleishman/sarel/bin/rosetta_scripts.default.linuxgccrelease " >> $jobname
#printf "/home/labs/fleishman/gideonla/my_ros/bin/rosetta_scripts.default.linuxgccrelease " >> $jobname


until [ -z $1 ]; do
	printf " $1 "
	shift
done >> $jobname

echo "" >> $jobname


#echo "bsub -L /bin/bash -G fleishman-lsf -q new-all.q -o $out -e $err $jobname" >> $commandname
echo "bsub -u /dev/null -C 1024  -R rusage[mem=1024] -L /bin/bash -G fleishman-wx-grp-lsf -q new-all.q -o $out -e $err /apps/RH6U4/blcr/0.8.5/bin/cr_run $jobname" >> $commandname
chmod +x $jobname

