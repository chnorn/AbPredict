cluster_radius=1

export LD_LIBRARY_PATH=/home/labs/fleishman/norn/scripts/bcl/bcl-3.0.1-Linux-x86_64
bcl_app=/home/labs/fleishman/norn/scripts/bcl/bcl-3.0.1-Linux-x86_64/bcl-apps-release-static.exe
license=/home/labs/fleishman/norn/scripts/bcl/bcl.license


for i in cluster_analysis/ca_structures/*
do 

	echo "now clustering "$i

	$bcl_app bcl:Cluster -distance_input_file $i/ll_rmsd_out.mat -input_format TableLowerTriangle -output_format Rows Centers -output_file $i/ll -linkage Average -output_pymol 1000 5 100 10000 10 $i/ll.py -remove_internally_similar_nodes $cluster_radius -pymol_label_output_string -license_file $license  

done

rm n0c1.out n1c0.out n1c1.out lp_contacts.out lpd.out lp.out


