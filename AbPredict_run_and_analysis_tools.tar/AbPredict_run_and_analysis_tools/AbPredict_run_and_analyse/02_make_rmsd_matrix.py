import os, glob
 
os.system("cat *_rmsd.txt > rmsd_file.txt")
os.system("rm 01parallel_make_rmsds.????.*")

# ----------------------------------------------------------
# User input
# ----------------------------------------------------------
in_directory = 'cluster_analysis/aligned_structures/'
out_directory = 'cluster_analysis/ca_structures/'

# ----------------------------------------------------------
# Setup output directories
# ----------------------------------------------------------
native_list = []
for path in glob.glob(in_directory+'*'):
	native_list.append(path.split('/')[2])
for native in native_list:
	out_subdir = out_directory+native
	if not os.path.exists(out_subdir):
	    os.makedirs(out_subdir)

# ----------------------------------------------------------
# Select which atoms that should be used for clustering
# Below I select the C+N atoms of the main chain
# which are also used for rmsd calculation
# ----------------------------------------------------------
f_vH_cores = open('vL_vH_natives/vH_annotation_cores.txt','r')
f_vL_cores = open('vL_vH_natives/vL_annotation_cores.txt','r')
f_vH_CDRs = open('vL_vH_natives/vH_annotation_CDRs.txt','r')
f_vL_CDRs = open('vL_vH_natives/vL_annotation_CDRs.txt','r')

def load_annotation(annotation_file,key):
   annotation_dict[key] = {}
   for line in annotation_file:
      pdbName = line.split()[0]
      annotation_dict[key][pdbName] = []
      for edge in line.split()[1:]:
         annotation_dict[key][pdbName].append(edge)


annotation_dict = {}
load_annotation(f_vH_cores,'vH_cores')
load_annotation(f_vL_cores,'vL_cores')
load_annotation(f_vH_CDRs,'vH_CDRs')
load_annotation(f_vL_CDRs,'vL_CDRs')

for native in native_list:
	L1_start = annotation_dict['vL_CDRs'][native][0]
	L1_end   = annotation_dict['vL_CDRs'][native][1]
	L2_start = annotation_dict['vL_CDRs'][native][2]
	L2_end   = annotation_dict['vL_CDRs'][native][3]
	L3_start = annotation_dict['vL_CDRs'][native][4]
	L3_end   = annotation_dict['vL_CDRs'][native][5]

	H1_start = annotation_dict['vH_CDRs'][native][0]
	H1_end = annotation_dict['vH_CDRs'][native][1]
	H2_start = annotation_dict['vH_CDRs'][native][2]
	H2_end = annotation_dict['vH_CDRs'][native][3]
	H3_start = annotation_dict['vH_CDRs'][native][4]
	H3_end = annotation_dict['vH_CDRs'][native][5]

	template_model = glob.glob(in_directory+native+'/*')[0]
	command = "awk '{if ($3 == \"C\" || $3 == \"O\") print $6,$3}' " + template_model + "| awk '$1 >= "+ L1_start +" && $1<= "+ L1_end+"' " + ' > '+out_directory+native+'/la.lst'
	os.system(command)
	command = "awk '{if ($3 == \"C\" || $3 == \"O\") print $6,$3}' " + template_model + "| awk '$1 >= "+ L2_start +" && $1<= "+ L2_end+"' " + ' >> '+out_directory+native+'/la.lst'
        os.system(command)
	command = "awk '{if ($3 == \"C\" || $3 == \"O\") print $6,$3}' " + template_model + "| awk '$1 >= "+ L3_start +" && $1<= "+ L3_end+"' " + ' >> '+out_directory+native+'/la.lst'
        os.system(command)
	command = "awk '{if ($3 == \"C\" || $3 == \"O\") print $6,$3}' " + template_model + "| awk '$1 >= "+ H1_start +" && $1<= "+ H1_end+"' " + ' >> '+out_directory+native+'/la.lst'
        os.system(command)
	command = "awk '{if ($3 == \"C\" || $3 == \"O\") print $6,$3}' " + template_model + "| awk '$1 >= "+ H2_start +" && $1<= "+ H2_end+"' " + ' >> '+out_directory+native+'/la.lst'
        os.system(command)
	command = "awk '{if ($3 == \"C\" || $3 == \"O\") print $6,$3}' " + template_model + "| awk '$1 >= "+ H3_start +" && $1<= "+ H3_end+"' " + ' >> '+out_directory+native+'/la.lst'
        os.system(command)


# ----------------------------------------------------------
# Make some extra input files needed for the rmsd script
# ----------------------------------------------------------

# Only cluster the top 5% by energy
print "About to find top 5% scoring structures"
model_vs_score = {}
f_open = open('rmsd_file.txt','r')
for line in f_open:
	pdbName = line.split()[0].split('/')[1].split('_')[0]
	modelName = line.split()[0].split('/')[1]
	score =  float(line.split()[1])
	
	if not pdbName in model_vs_score:
		model_vs_score[pdbName] = []
		print "Now reading in "+pdbName
	model_vs_score[pdbName].append((score , modelName))

for pdbName in native_list:
	#if '1X9Q' in pdbName:
	#	continue
	
	os.system('echo "" > '+out_directory+pdbName+'/pa.lst')
	os.system('echo "cutoff 4.00" > '+out_directory+pdbName+'/cutoff')

	f_out = open(out_directory+pdbName+'/pdb.lst','w')
	noModels = len(model_vs_score[pdbName])
	nTop5 = int(noModels*0.05)

	top5List = sorted(model_vs_score[pdbName], key=lambda x: x[0])[0:nTop5]
	print "Preparing "+pdbName+" structures"
	for energy,modelName in top5List:
		f_out.write(out_directory+pdbName+'/'+modelName+'\n')
		
		# Also prepare input files for rmsd by renaming ATOM to HETATM...
		modelPath = in_directory+pdbName+'/'+modelName
		command = "awk '$1==\"ATOM\"' " + modelPath + "| sed 's/ATOM  /HETATM/g' > " + modelPath.replace('aligned_structures','ca_structures')		
		os.system(command)


print "Script for calculating rmsds will now be made"
# ----------------------------------------------------------
# Prep script for rmsd calculations 
# ----------------------------------------------------------
from subprocess import call
f_commands = open('03_calculate_rmsd.sh','w')
for native in native_list:
	f_commands.write('echo  "calculating rmsd for '+native+'"'+'\n')
	command = '/home/labs/fleishman/norn/scripts/tmf_rmsd '+out_directory+native+'/pdb.lst '+out_directory+native+'/ll_rmsd_out.mat '+out_directory+native+'/lp_rmsd_out.mat '+out_directory+native+'/pp_rmsd_out.mat '+out_directory+native+'/la.lst '+out_directory+native+'/pa.lst '+out_directory+native+'/cutoff > /dev/null'
	#print native
	#print command
	#os.system(command)
	f_commands.write(command+'\n')
	#call(command, shell=True)
	# clean up
	#os.system("rm lp_contacts.out lpd.out lp.out n0c1.out n1c0.out n1c1.out pp_rmsd_out.mat")
	f_commands.write("rm lp_contacts.out lpd.out lp.out n0c1.out n1c0.out n1c1.out > /dev/null "+'\n')
#os.system("bash tmp_commands.sh")
#call("rm lp_contacts.out lpd.out lp.out n0c1.out n1c0.out n1c1.out ",shell=True)
f_commands.write("rm lp_contacts.out lpd.out lp.out n0c1.out n1c0.out n1c1.out > /dev/null"+'\n')

print "Now you should run bash 03_calculate_rmsd.sh"

