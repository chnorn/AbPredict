rm rmsd_file.txt
rm ????_rmsd.txt
rm 01parallel_make_rmsds.????.*
mv cluster_analysis tmp1
nohup rm -r tmp1 > log &

for i in $(cat in/sequences.txt | awk '{print $1}' | awk 'substr($0,1,1)!="#"'); do
	sed 's/%%insert%%/'$i'/g' 01parallel_make_rmsds.py > 01parallel_make_rmsds.$i.py
	nohup pymol -ck 01parallel_make_rmsds.$i.py > 01parallel_make_rmsds.$i.log &
	sleep 10s
done


