import os,  shutil, glob
from pylab import *
from matplotlib import pyplot as plt
from AbTools import load_clustering_data

# ------------------------------------------------------------------------------
# Prepare dictionaries
# ------------------------------------------------------------------------------ 
f_open = open('in/sequences.txt','r')
data_dict = {}
data_dict_top3 = {}
for line in f_open:
	if line.strip() == '':
        	continue	
	pdbid = line.split()[0]
	if '#' in pdbid: 
		continue
#	if '' in pdbid or '3XTL' in pdbid or 'A546' in pdbid or 'E483' in pdbid:
#		continue
	data_dict[pdbid] = {'score':[],'L1_rmsd':[],'L2_rmsd':[],'L3_rmsd':[],'H1_rmsd':[],'H2_rmsd':[],'H3_rmsd':[],'tilt':[],'total_rmsd':[],'rank':[]}
	for rank in [1,2,3]:
		if not pdbid in data_dict_top3:
			data_dict_top3[pdbid] = {}
		data_dict_top3[pdbid][rank] = {'score':0,'L1_rmsd':0,'L2_rmsd':0,'L3_rmsd':0,'H1_rmsd':0,'H2_rmsd':0,'H3_rmsd':0,'tilt':0,'total_rmsd':0,'rank':0,'name':''}

# ------------------------------------------------------------------------------
# Best RMSD from ASA2
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# Load in clustering data
# ------------------------------------------------------------------------------
node_dict = {}
node_vs_rank = {}
for pdb in data_dict.keys():
	node_vs_rank[pdb] = {}
	
	center_file = 'cluster_analysis/ca_structures/'+pdb+'/ll.Centers.'
	row_file = 'cluster_analysis/ca_structures/'+pdb+'/ll.Rows.'
	node_dict = load_clustering_data(center_file,node_dict,1)
	node_dict = load_clustering_data(row_file,node_dict,0)
	# print node_dict.keys()
	
	# print node_dict
	#print node_dict
	# print pdb, node_dict[pdb]
	node_dict_sorted = sorted(node_dict[pdb].items() , key=lambda x: x[1][1],reverse=True)
	
	rank = 1
	for entry in node_dict_sorted:
		node = entry[1][0]
		size = entry[1][1]
		if not node in node_vs_rank[pdb]:
			node_vs_rank[pdb][node] = rank
			rank += 1
		# print pdb, entry, rank
# print node_dict

# ------------------------------------------------------------------------------
# Load in rmsd data
# ------------------------------------------------------------------------------
f_open = open('rmsd_file.txt','r')
for line in f_open:
	pdb = line.split()[0].split('/')[1].split('_')[0]
	modelName = line.split()[0].split('/')[1]
	score =  float(line.split()[1])
	rms_L1 = float(line.split()[2])
	rms_L2 = float(line.split()[3])
	rms_L3 = float(line.split()[4])
	rms_H1 = float(line.split()[5])
	rms_H2 = float(line.split()[6])
	rms_H3 = float(line.split()[7])
	tilt   = float(line.split()[8])
	total_rmsd   = float(line.split()[11])

	try: 
		node = node_dict[pdb][modelName][0]
		rank = node_vs_rank[pdb][node]
	except:
		node = 100000
		rank = 100000
	
	data_dict[pdb]['score']  .append( score   )
	data_dict[pdb]['L1_rmsd'].append( rms_L1  )
	data_dict[pdb]['L2_rmsd'].append( rms_L2  )
	data_dict[pdb]['L3_rmsd'].append( rms_L3  )
	data_dict[pdb]['H1_rmsd'].append( rms_H1  )
	data_dict[pdb]['H2_rmsd'].append( rms_H2  )
	data_dict[pdb]['H3_rmsd'].append( rms_H3  )
	data_dict[pdb]['tilt']   .append( tilt    )
	data_dict[pdb]['total_rmsd'].append( total_rmsd    )
	data_dict[pdb]['rank'].append( rank )

	# Lowest energy models in three largest clusters
	if rank == 1 and score < data_dict_top3[pdb][1]['score']:
		data_dict_top3[pdb][1]['score']         = score 
		data_dict_top3[pdb][1]['L1_rmsd']       = rms_L1
		data_dict_top3[pdb][1]['L2_rmsd']       = rms_L2
		data_dict_top3[pdb][1]['L3_rmsd']       = rms_L3
		data_dict_top3[pdb][1]['H1_rmsd']       = rms_H1
		data_dict_top3[pdb][1]['H2_rmsd']       = rms_H2
		data_dict_top3[pdb][1]['H3_rmsd']       = rms_H3
		data_dict_top3[pdb][1]['tilt']          = tilt
		data_dict_top3[pdb][1]['total_rmsd']    = total_rmsd
		data_dict_top3[pdb][1]['rank']          = rank
		data_dict_top3[pdb][1]['name']          = modelName
		continue
	if rank == 2 and score < data_dict_top3[pdb][2]['score']:
		data_dict_top3[pdb][2]['score']         = score 
		data_dict_top3[pdb][2]['L1_rmsd']       = rms_L1
		data_dict_top3[pdb][2]['L2_rmsd']       = rms_L2
		data_dict_top3[pdb][2]['L3_rmsd']       = rms_L3
		data_dict_top3[pdb][2]['H1_rmsd']       = rms_H1
		data_dict_top3[pdb][2]['H2_rmsd']       = rms_H2
		data_dict_top3[pdb][2]['H3_rmsd']       = rms_H3
		data_dict_top3[pdb][2]['tilt']          = tilt
		data_dict_top3[pdb][2]['total_rmsd']    = total_rmsd
		data_dict_top3[pdb][2]['rank']          = rank
		data_dict_top3[pdb][2]['name']          = modelName
		continue
	if rank == 3 and score < data_dict_top3[pdb][3]['score']:
		data_dict_top3[pdb][3]['score']         = score 
		data_dict_top3[pdb][3]['L1_rmsd']       = rms_L1
		data_dict_top3[pdb][3]['L2_rmsd']       = rms_L2
		data_dict_top3[pdb][3]['L3_rmsd']       = rms_L3
		data_dict_top3[pdb][3]['H1_rmsd']       = rms_H1
		data_dict_top3[pdb][3]['H2_rmsd']       = rms_H2
		data_dict_top3[pdb][3]['H3_rmsd']       = rms_H3
		data_dict_top3[pdb][3]['tilt']          = tilt
		data_dict_top3[pdb][3]['total_rmsd']    = total_rmsd
		data_dict_top3[pdb][3]['rank']          = rank
		data_dict_top3[pdb][3]['name']          = modelName
		continue

# print data_dict_top3['4M43'][1]


	
# ------------------------------------------------------------------------------
# Write out best clusters
# ------------------------------------------------------------------------------

measureables = ['L1_rmsd','L2_rmsd','L3_rmsd','H1_rmsd','H2_rmsd','H3_rmsd','tilt','total_rmsd','rank','name']
f_out = open('best_clusters.txt','w')
for pdb in data_dict_top3:
	for rank in data_dict_top3[pdb]:
		f_out.write(pdb+' ')
		for measure in measureables:
			f_out.write(str(data_dict_top3[pdb][rank][measure])+' ')
		f_out.write('\n')
	
# ------------------------------------------------------------------------------
# Make the plots
# ------------------------------------------------------------------------------
fig = plt.figure()
fig_num = 1
row = 1

def count_n_with_rank(rankList,rank):
	n = 0
	for r in rankList:
		if r == rank:
			n+=1
	return n

measureables = ['L1_rmsd','L2_rmsd','L3_rmsd','H1_rmsd','H2_rmsd','H3_rmsd','tilt','total_rmsd']
rows = len(data_dict.keys())
# rows = 1
columns = len(measureables)
# columns = 1
lim_rmsds = [0,5]
lim_tilt = [-20,20]
pdb_list = data_dict.keys()
for pdb in pdb_list: #data_dict.keys():
	#if pdb == '1X9Q':
	#		continue
	# print pdb,data_dict_best[pdb]
	column = 1
	
	print pdb,len(data_dict[pdb]['rank']),count_n_with_rank(data_dict[pdb]['rank'],1),count_n_with_rank(data_dict[pdb]['rank'],2),count_n_with_rank(data_dict[pdb]['rank'],3)
	# print pdb,data_dict[pdb]
	
	ymin = sorted(data_dict[pdb]['score'])[0] - 20
	lim_reu = [ymin,ymin+50]
	# print pdb, data_dict_top3[pdb][1]
	# print pdb, data_dict_top3[pdb][2]
	# print pdb, data_dict_top3[pdb][3]
	for val in measureables:
		#if val != 'total_rmsd':
		#	fig_num += 1
		#	column += 1
		#	continue
		ax1 = fig.add_subplot(rows,columns,fig_num)
		if 'rmsd' in val:
			xlab = val.replace('_',' ')
		if 'tilt' in val:
			xlab = val.replace('tilt','Tilt')
		ax1.set_xlabel(xlab,fontsize=5)
		
		ax1.tick_params(axis='both', which='major', labelsize=4, length=2)
		ax1.set_ylim(lim_reu)
		if 'rmsd' in val:
			ax1.set_xlim(lim_rmsds)
		if 'tilt' in val:
			ax1.set_xlim(lim_tilt)
			ax1.locator_params(nbins=4)
		ax1.scatter(data_dict[pdb][val],data_dict[pdb]['score'],s=0.3,c='black', zorder=0)
		# print data_dict_top3[pdb][1]
		ax1.scatter(data_dict_top3[pdb][1][val],data_dict_top3[pdb][1]['score'],s=18,c='blue',edgecolors='none', zorder=1)
		ax1.scatter(data_dict_top3[pdb][2][val],data_dict_top3[pdb][2]['score'],s=12,c='orange',edgecolors='none', zorder=2)
		ax1.scatter(data_dict_top3[pdb][3][val],data_dict_top3[pdb][3]['score'],s=6,c='red',edgecolors='none', zorder=3)		
		
		
		
		# Remove various axis numbers
		if column==1:
			# ax1.set_ylabel('Energy',fontsize=8)
			ax1.set_ylabel(pdb,fontsize=5)
		if column!=1:
			ax1.yaxis.set_major_formatter( NullFormatter() )		
		
		fig_num += 1
		column += 1
		plt.setp(ax1.get_yticklabels()[0], visible=False)
		plt.setp(ax1.get_yticklabels()[-1], visible=False)
		plt.setp(ax1.get_xticklabels()[0], visible=False)
		plt.setp(ax1.get_xticklabels()[-1], visible=False)
	row += 1

plt.subplots_adjust(wspace=0, hspace=0)
plt.savefig('score_vs_rmsd.png',dpi=300)

# plt.show()
