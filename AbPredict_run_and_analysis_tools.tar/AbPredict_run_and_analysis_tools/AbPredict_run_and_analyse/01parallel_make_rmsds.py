import glob
from itertools import tee, izip
from AbTools import vH_vL_angle
import os


# To parallelize: https://medium.com/building-things-on-the-internet/40e9b2b36148
target_structure = ['%%insert%%']
outfilename = target_structure[0]+'_rmsd.txt'

# ---------------------------------------------
# User imput
# ---------------------------------------------
#in_directory = 'out_even_less_rotamers/'
in_directory = 'pdb/'
out_directory = 'cluster_analysis/aligned_structures/'

# ---------------------------------------------
# Misc functions
# ---------------------------------------------

def pairwise(iterable):
    "s -> (s0,s1), (s1,s2), (s2, s3), ..."
    a, b = tee(iterable)
    next(b, None)
    return izip(a, b)

# -----------------------------------------------

# Load in annotation 
f_vH_cores = open('vL_vH_natives/vH_annotation_cores.txt','r')
f_vL_cores = open('vL_vH_natives/vL_annotation_cores.txt','r')
f_vH_CDRs = open('vL_vH_natives/vH_annotation_CDRs.txt','r')
f_vL_CDRs = open('vL_vH_natives/vL_annotation_CDRs.txt','r')

def load_annotation(annotation_file,key):
	annotation_dict[key] = {}
	for line in annotation_file:
		pdbName = line.split()[0]
		annotation_dict[key][pdbName] = [] 
		for edge in line.split()[1:]:
			annotation_dict[key][pdbName].append(edge)

annotation_dict = {}
load_annotation(f_vH_cores,'vH_cores')
load_annotation(f_vL_cores,'vL_cores')
load_annotation(f_vH_CDRs,'vH_CDRs')
load_annotation(f_vL_CDRs,'vL_CDRs')

# Pymol misc
cmd.set("suspend_undo", 1)

# IO
outfile = open(outfilename,'w')

# Setup output directory
if not os.path.exists(out_directory):
    os.makedirs(out_directory)
for native in target_structure:
	if not os.path.exists(out_directory+'/'+native):
		os.makedirs(out_directory+'/'+native)

# Load in data from Rosetta out files
score_dict = {}

# Load in scores 
for native in target_structure:
	print "listing a lot of files for "+native
	scoreFiles = glob.glob(in_directory+native+'*.sc')
	for scoreFile in scoreFiles:
		f_open = open(scoreFile,'r')
		for line in f_open:
			if native in line: # this is to get the line with the scores
				modelName = line.split()[-1].split('/')[1]
				totalScore = str(line.split()[1])
				score_dict[modelName] = totalScore

# Load pdbs
n = 0
for native in target_structure:
	# native = '4KQ3' 
	cmd.do('rei')
	native_path = 'vL_vH_natives/'+native+'.pdb'
	cmd.do("load %s" % (native_path))
	# -------------- Get core selections ------------------------
	vH_native_core_sele = native+'_vH_core'
	vL_native_core_sele = native+'_vL_core'
	streches_vH = ''
	streches_vL = ''
	n=0
	for v, w in pairwise(annotation_dict['vH_cores'][native]):
		if n % 2 == 0:
			streches_vH += native+' and resi '+v+'-'+w+' or '
		n+=1
	n=0
	for v, w in pairwise(annotation_dict['vL_cores'][native]):
		if n % 2 == 0:
			streches_vL += native+' and resi '+v+'-'+w+' or '
		n+=1
	cmd.select(vH_native_core_sele,streches_vH[:-4])
	cmd.select(vL_native_core_sele,streches_vL[:-4])
	# ---------------  CDR selections     ---------------------
	L1_start = annotation_dict['vL_CDRs'][native][0]
	L1_end   = annotation_dict['vL_CDRs'][native][1]
	L2_start = annotation_dict['vL_CDRs'][native][2]
	L2_end   = annotation_dict['vL_CDRs'][native][3]
	L3_start = annotation_dict['vL_CDRs'][native][4]
	L3_end   = annotation_dict['vL_CDRs'][native][5]
	
	H1_start = annotation_dict['vH_CDRs'][native][0]
	H1_end = annotation_dict['vH_CDRs'][native][1]
	H2_start = annotation_dict['vH_CDRs'][native][2]
	H2_end = annotation_dict['vH_CDRs'][native][3]
	H3_start = annotation_dict['vH_CDRs'][native][4]
	H3_end = annotation_dict['vH_CDRs'][native][5]
	# ---------------  AbAngle selections ---------------------
	atom1 = int(annotation_dict['vL_cores'][native][4])
	atom2 = int(annotation_dict['vL_cores'][native][5])-2
	atom3 = int(annotation_dict['vL_cores'][native][12])
	atom4 = int(annotation_dict['vL_cores'][native][13])-2
	
	atom5 = int(annotation_dict['vH_cores'][native][4] )
	atom6 = int(annotation_dict['vH_cores'][native][5] )-3
	atom7 = int(annotation_dict['vH_cores'][native][14] )+2
	atom8 = int(annotation_dict['vH_cores'][native][15] )-2
	
	# -------------- Native structure angle ------------------
	ll_vH_coords = []
	ll_vL_coords = []
	xyz = cmd.get_model(native+' and name ca', 1).get_coord_list()
	for coord in range(atom1-1,atom2)+range(atom3-1,atom4):
		ll_vL_coords.append(xyz[coord+1])
		# print xyz[coord+1][0],xyz[coord+1][1],xyz[coord+1][2]
	for coord in range(atom5-1,atom6)+range(atom7-1,atom8):
		ll_vH_coords.append(xyz[coord+1])
		# print xyz[coord+1][0],xyz[coord+1][1],xyz[coord+1][2]
	native_angle = vH_vL_angle(ll_vH_coords,ll_vL_coords)
	
	# ============== Calculate over all models ================
	
	l_models = glob.glob(in_directory+'*'+native+'*pdb')
	for model in l_models:
		# model = 'out_less_rotamers_new_xml/4KQ3_1615_4KQ3_0001.pdb' #D
		modelName = model.split('/')[1].replace('.pdb','')
		print "trying to load " + model
		try:
			cmd.load(model)
		except:
			print "Could not load " + model		
			continue
		# calculate total rmsd and save the aligned structure
		cmd.align(modelName,native)
		rms_total = str(cmd.rms_cur(native+' and name c+o',modelName+' and name c+o'))
		cmd.save(out_directory+native+'/'+modelName+'.pdb',modelName)
		
		# calculate rmsd for vH
		cmd.align(modelName,vH_native_core_sele)
		cmd.select('H1_model_'+native, modelName+' and resi '+H1_start+'-'+H1_end)
		cmd.select('H1_native_'+native, native+' and resi '+H1_start+'-'+H1_end )
		cmd.select('H2_model_'+native, modelName+' and resi '+H2_start+'-'+H2_end )
		cmd.select('H2_native_'+native, native+' and resi '+H2_start+'-'+H2_end)
		cmd.select('H3_model_'+native, modelName+' and resi '+H3_start+'-'+H3_end )
		cmd.select('H3_native_'+native, native+' and resi '+H3_start+'-'+H3_end)
		rms_H1 = str(cmd.rms_cur('H1_model_'+native+' and name c+o','H1_native_'+native+' and name c+o'))
		rms_H2 = str(cmd.rms_cur('H2_model_'+native+' and name c+o','H2_native_'+native+' and name c+o'))
		rms_H3 = str(cmd.rms_cur('H3_model_'+native+' and name c+o','H3_native_'+native+' and name c+o'))
				
		# calculate rmsd for vL
		cmd.align(modelName,vL_native_core_sele)
		cmd.select('L1_model_'+native, modelName+' and resi '+L1_start+'-'+L1_end)
		cmd.select('L1_native_'+native, native+' and resi '+L1_start+'-'+L1_end )
		cmd.select('L2_model_'+native, modelName+' and resi '+L2_start+'-'+L2_end )
		cmd.select('L2_native_'+native, native+' and resi '+L2_start+'-'+L2_end)
		cmd.select('L3_model_'+native, modelName+' and resi '+L3_start+'-'+L3_end )
		cmd.select('L3_native_'+native, native+' and resi '+L3_start+'-'+L3_end)
		rms_L1 = str(cmd.rms_cur('L1_model_'+native+' and name c+o','L1_native_'+native+' and name c+o'))
		rms_L2 = str(cmd.rms_cur('L2_model_'+native+' and name c+o','L2_native_'+native+' and name c+o'))
		rms_L3 = str(cmd.rms_cur('L3_model_'+native+' and name c+o','L3_native_'+native+' and name c+o'))
		
		# calculate AbAngle, segments according to Abhinandan
		ll_vH_coords = []
		ll_vL_coords = []
		xyz = cmd.get_model(modelName+' and name ca', 1).get_coord_list()
		for coord in range(atom1-1,atom2)+range(atom3-1,atom4):
			ll_vL_coords.append(xyz[coord+1])
			# print xyz[coord+1][0],xyz[coord+1][1],xyz[coord+1][2]
		for coord in range(atom5-1,atom6)+range(atom7-1,atom8):
			ll_vH_coords.append(xyz[coord+1])
			# print xyz[coord+1][0],xyz[coord+1][1],xyz[coord+1][2]
		model_angle = vH_vL_angle(ll_vH_coords,ll_vL_coords)
		
		tilt = str(model_angle - native_angle) #str(dihedral_vL_aligned-dihedral_vHvL_aligned)
		
		#try:
		outfile.write(model+' '+score_dict[modelName]+' '+rms_L1+' '+rms_L2+' '+rms_L3+' '+rms_H1+' '+rms_H2+' '+rms_H3+' '+tilt+' '+str(model_angle)+' '+str(native_angle)+' '+rms_total+'\n')
		#except:
		#	print "Failing for this structure"
		#	pass
			
		cmd.do("delete %s" % modelName)			
		
		print "analysed "+str(n)+" structures"
		n+=1
