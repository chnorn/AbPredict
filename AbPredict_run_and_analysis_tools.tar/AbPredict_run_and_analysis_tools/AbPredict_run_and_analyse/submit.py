import os,  shutil, glob, random
import make_comments as find_segments


###########################################################
#        USER OPTIONS
###########################################################

ab_sequence_file = 'in/sequences.txt' 

# torsion databases 
kappa_config_dir = '/home/labs/fleishman/norn/Rosetta/main/database/protocol_data/splice/antibodies/torsion_databases/kappa/'
lambda_config_dir = '/home/labs/fleishman/norn/Rosetta/main/database/protocol_data/splice/antibodies/torsion_databases/lambda/'
template_pdb_kappa = '/home/labs/fleishman/norn/Rosetta/main/database/protocol_data/splice/antibodies/template_pdbs/2BRR.ppk.pdb'
template_pdb_lambda = '/home/labs/fleishman/norn/Rosetta/main/database/protocol_data/splice/antibodies/template_pdbs/2G75.ppk.pdb'
kappa_rbo_path = '/home/labs/fleishman/norn/Rosetta/main/database/protocol_data/splice/antibodies/RBO_databases/kappa/rb.database'
lambda_rbo_path = '/home/labs/fleishman/norn/Rosetta/main/database/protocol_data/splice/antibodies/RBO_databases/lambda/rb.database'


###########################################################

# Load in sequences 
f_open = open(ab_sequence_file,'r')
input_dict = {}
for line in f_open:
	if line.strip() == '':
		continue	
	try:
		abName = line.split()[0]
		if abName.startswith('#'):
			continue
		input_dict[abName] = {}
		input_dict[abName]['lightChain'] = line.split()[1]
		input_dict[abName]['heavyChain'] = line.split()[2]
		input_dict[abName]['fullSequence'] = input_dict[abName]['lightChain']+input_dict[abName]['heavyChain']
		input_dict[abName]['lightChainType'] = line.split()[3]
	except:
		print "Could not read line from "+ab_sequence_file+": "+line
		pass

# Perform sanity check to make sure that user gave the correct input
for abName in input_dict:	
	VL = input_dict[abName]['lightChain']
        VH = input_dict[abName]['heavyChain']
        chainType = input_dict[abName]['lightChainType']
	allSegmentEndingsAreCanonical = True
        find_segments.input_sanity_check( VL , VH , chainType , allSegmentEndingsAreCanonical )
	

# Read in torsion databases
torsion_db_dict = {'lambda':{}, 'kappa':{}}
torsion_db_dict['lambda'] = find_segments.read_torsion_db_files( lambda_config_dir )
torsion_db_dict['kappa'] = find_segments.read_torsion_db_files( kappa_config_dir )

# Clean up before working
os.system('rm -r job/')
os.system('rm -r out/')
os.system('rm -r pdb/')
os.system('rm -r err/')
os.system('rm command')
os.system('rm checkpoint/*')
os.system('rm *pdb')

os.system('mkdir job/')
os.system('mkdir out/')
os.system('mkdir pdb/')
os.system('mkdir err/')

##############################################
#               Submit jobs
# allq_sub.sh is system specific and should
# contain the setup for submitting jobs to 
# the queueing system. If running only one 
# job you can replace that with 
# rosetta_scripts.default.linuxgccrelease
#############################################
print "About to submit jobs"
for abName in input_dict.keys():
	chainType = input_dict[abName]['lightChainType']
	VL = input_dict[abName]['lightChain']
        VH = input_dict[abName]['heavyChain']	
	
	# Set paths for rosetta
	if chainType == 'lambda':
		configdir = lambda_config_dir
		source_pdb = template_pdb_lambda
		template_pdb = template_pdb_lambda
		rb_database = lambda_rbo_path	
	elif chainType == 'kappa':
		configdir = kappa_config_dir
		source_pdb = template_pdb_kappa
		template_pdb = template_pdb_kappa
		rb_database = kappa_rbo_path	
	# Select random segments of correct length from database to seed the prediction trajectory
        (vl_n_tail_len, vl_CDR1_CDR2_len, vl_CDR3_c_tail_len) = find_segments.determine_segment_lengths(VL)
        (vh_n_tail_len, vh_CDR1_CDR2_len, vh_CDR3_c_tail_len) = find_segments.determine_segment_lengths(VH)
	
	# Generate the job scripts for the cluster and randomly select segments for every job
	for i in range(1,50):


		vH_H3_vL_L3_list = find_segments.output_segment_info(torsion_db_dict[chainType],vl_CDR1_CDR2_len,vl_CDR3_c_tail_len,vh_CDR1_CDR2_len,vh_CDR3_c_tail_len,abName,'returnList',chainType)
		input_dict[abName]['seg_H1_H2'] = vH_H3_vL_L3_list[0]
		input_dict[abName]['seg_H3'] =    vH_H3_vL_L3_list[1]
        	input_dict[abName]['seg_L1_L2'] = vH_H3_vL_L3_list[2]
        	input_dict[abName]['seg_L3'] =    vH_H3_vL_L3_list[3]
		
		i = str(i)
		os.system('./allq_sub.sh '
		+ ' -parser:protocol protocol/140911_AbPredict.xml ' 
		+ ' -s ' + source_pdb 
		+ ' -parser:script_vars prefix=checkpoint/'+abName+'.'+i+'.pdb.c'
		+ ' -parser:script_vars sequence='+input_dict[abName]['fullSequence']
		+ ' -parser:script_vars entry_L3='+input_dict[abName]['seg_L3']
		+ ' -parser:script_vars entry_H3='+input_dict[abName]['seg_H3']
		+ ' -parser:script_vars entry_H1_H2='+input_dict[abName]['seg_H1_H2']
		+ ' -parser:script_vars entry_L1_L2='+input_dict[abName]['seg_L1_L2']
		+ ' -parser:script_vars configdir='+configdir
		+ ' -parser:script_vars rbo_db='+rb_database
		+ ' -parser:script_vars template_pdb='+template_pdb
		+ ' -out:prefix pdb/'+abName+'_'+i+'_'
		+ ' @flags_predict '
		+ ' -overwrite ')

# shuffle the jobs, so we will get outputs from all targets as they finish
os.system("cat command | perl -MList::Util=shuffle -e 'print shuffle(<STDIN>);' > tmp2") 
os.system("mv tmp2 command")	

# Submit to cluster
os.system('chmod +x command')
os.system('./command')
