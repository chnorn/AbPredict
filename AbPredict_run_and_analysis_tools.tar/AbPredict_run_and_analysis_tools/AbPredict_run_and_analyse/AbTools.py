def vH_vL_angle(ll_vH_coords,ll_vL_coords):
	# ll_vH_coords = [[1,0.2,2],[1.2,0.2,2.3],[1.5,0.5,5],[1.8,0.6,8],[2,1,10],[2.5,1,15]]
	# ll_vL_coords = [[6,5,-1.5],[5,5,-2],[6,5,-7],[5,6,-4],[5,5.5,3],[5,6,6],[5,6,-5]]
	
	import numpy as np
	
	# Load in data
	data_vH = np.array(ll_vH_coords)
	data_vL = np.array(ll_vL_coords)
	
	# Calculate the mean of the points, i.e. the 'center' of the cloud
	datamean_vH = data_vH.mean(axis=0)
	datamean_vL = data_vL.mean(axis=0)
	
	# Do an SVD on the mean-centered data.
	uu_vH, dd_vH, vv_vH = np.linalg.svd(data_vH - datamean_vH)
	uu_vL, dd_vL, vv_vL = np.linalg.svd(data_vL - datamean_vL)
	
	# Now vv[0] contains the first principal component, i.e. the direction
	# vector of the 'best fit' line in the least squares sense.
	
	# Now generate some points along this best fit line, for plotting.
	
	# I use -7, 7 since the spread of the data is roughly 14
	# and we want it to have mean 0 (like the points we did
	# the svd on). Also, it's a straight line, so we only need 2 points.
	linepts_vH = vv_vH[0] * np.mgrid[0:8:2j][:, np.newaxis]
	linepts_vL = vv_vL[0] * np.mgrid[0:8:2j][:, np.newaxis]
	
	# shift by the mean to get the line in the right place
	linepts_vH += datamean_vH
	linepts_vL += datamean_vL
	
	# Normal vector to plane
	vec1 = linepts_vH[0]-linepts_vH[1]
	vec2 = linepts_vH[0]-linepts_vL[0]
	normal = np.cross(vec1,vec2)
	
	### Verify that everything looks right.
	# import matplotlib.pyplot as plt
	# import mpl_toolkits.mplot3d as m3d
	# d = np.dot(-datamean_vH,normal)
	# xx, yy = np.meshgrid(range(6), range(6))
	# z = (-normal[0] * xx - normal[1] * yy - d) * 1. /normal[2]
	# ax = m3d.Axes3D(plt.figure())
	# ax.scatter3D(*data_vH.T)
	# ax.plot3D(*linepts_vH.T)
	# ax.scatter3D(*data_vL.T)
	# ax.plot3D(*linepts_vL.T)
	# ax.plot_surface(xx, yy, z)

	angle_between_plane_and_vector = np.degrees(np.arcsin(np.absolute(np.dot(vv_vL[0],normal)/(np.linalg.norm(normal)*np.linalg.norm(vv_vL[0])))))
	# plt.show()
	return angle_between_plane_and_vector


def load_clustering_data(inputFile,cluster_dict,isCenter):
	# Load in data
	print "Trying to load "+inputFile
	f_open = open(inputFile,'r')
	for line in f_open:
		structurePath = line.split()[5]
		name = structurePath.split('/')[-1]
		pdbid = name.split('_')[0]
		leaf = line.split()[13]
		clusterSize = int(line.split()[9])
		node = line.split()[1]
		if leaf == '1':
			if not pdbid in cluster_dict:
				cluster_dict[pdbid] = {}
			cluster_dict[pdbid][name] = (node,clusterSize,isCenter)
	return cluster_dict
