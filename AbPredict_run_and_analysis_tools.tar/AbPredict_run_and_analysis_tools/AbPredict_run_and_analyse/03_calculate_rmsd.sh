/home/labs/fleishman/norn/scripts/tmf_rmsd cluster_analysis/ca_structures/A546/pdb.lst cluster_analysis/ca_structures/A546/ll_rmsd_out.mat cluster_analysis/ca_structures/A546/lp_rmsd_out.mat cluster_analysis/ca_structures/A546/pp_rmsd_out.mat cluster_analysis/ca_structures/A546/la.lst cluster_analysis/ca_structures/A546/pa.lst cluster_analysis/ca_structures/A546/cutoff
rm lp_contacts.out lpd.out lp.out n0c1.out n1c0.out n1c1.out 
/home/labs/fleishman/norn/scripts/tmf_rmsd cluster_analysis/ca_structures/E483/pdb.lst cluster_analysis/ca_structures/E483/ll_rmsd_out.mat cluster_analysis/ca_structures/E483/lp_rmsd_out.mat cluster_analysis/ca_structures/E483/pp_rmsd_out.mat cluster_analysis/ca_structures/E483/la.lst cluster_analysis/ca_structures/E483/pa.lst cluster_analysis/ca_structures/E483/cutoff
rm lp_contacts.out lpd.out lp.out n0c1.out n1c0.out n1c1.out 
/home/labs/fleishman/norn/scripts/tmf_rmsd cluster_analysis/ca_structures/1XTL/pdb.lst cluster_analysis/ca_structures/1XTL/ll_rmsd_out.mat cluster_analysis/ca_structures/1XTL/lp_rmsd_out.mat cluster_analysis/ca_structures/1XTL/pp_rmsd_out.mat cluster_analysis/ca_structures/1XTL/la.lst cluster_analysis/ca_structures/1XTL/pa.lst cluster_analysis/ca_structures/1XTL/cutoff
rm lp_contacts.out lpd.out lp.out n0c1.out n1c0.out n1c1.out 
/home/labs/fleishman/norn/scripts/tmf_rmsd cluster_analysis/ca_structures/3XTL/pdb.lst cluster_analysis/ca_structures/3XTL/ll_rmsd_out.mat cluster_analysis/ca_structures/3XTL/lp_rmsd_out.mat cluster_analysis/ca_structures/3XTL/pp_rmsd_out.mat cluster_analysis/ca_structures/3XTL/la.lst cluster_analysis/ca_structures/3XTL/pa.lst cluster_analysis/ca_structures/3XTL/cutoff
rm lp_contacts.out lpd.out lp.out n0c1.out n1c0.out n1c1.out 
rm lp_contacts.out lpd.out lp.out n0c1.out n1c0.out n1c1.out 
