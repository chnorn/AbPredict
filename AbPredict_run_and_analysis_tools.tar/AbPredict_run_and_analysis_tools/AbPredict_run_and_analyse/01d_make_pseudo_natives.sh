for i in $(cat in/sequences.txt | awk '{print $1}' | awk 'substr($0,1,1)!="#"'); do
	grep ppk pdb/$i*sc | sort -nk 2 | head -1 | awk '{print "cp "$NF".pdb vL_vH_natives/'$i'.pdb"}'
done


