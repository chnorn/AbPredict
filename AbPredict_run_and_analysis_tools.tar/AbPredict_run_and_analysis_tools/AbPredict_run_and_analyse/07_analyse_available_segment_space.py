import os,  shutil, glob, random
import make_comments as find_segments


###########################################################
#        USER OPTIONS
###########################################################

ab_sequence_file = 'in/sequences.txt' 

# I'm here running a benchmark so I'm using special unbiased torsion databases
kappa_config_dir = '/home/labs/fleishman/norn/prediction/sample_dofs/unbiased_config_dirs/2BRR_config_dir/' # for kappa antibodies
lambda_config_dir = '/home/labs/fleishman/norn/prediction/sample_dofs/unbiased_config_dirs/2G75_config_dir/' # for lambda antibodies
#kappa_config_dir='/Users/christoffernorn/eden_mount/eden/prediction/sample_dofs/unbiased_config_dirs/2BRR_config_dir/'
#lambda_config_dir='/Users/christoffernorn/eden_mount/eden/prediction/sample_dofs/unbiased_config_dirs/2BRR_config_dir/'

###########################################################

# Load in sequences 
f_open = open(ab_sequence_file,'r')
input_dict = {}
for line in f_open:
	if line.strip() == '':
        	continue
	try:
		abName = line.split()[0]
		if '#' in abName:
			continue
		input_dict[abName] = {}
		input_dict[abName]['lightChain'] = line.split()[1]
		input_dict[abName]['heavyChain'] = line.split()[2]
		input_dict[abName]['fullSequence'] = input_dict[abName]['lightChain']+input_dict[abName]['heavyChain']
		input_dict[abName]['lightChainType'] = line.split()[3]
	except:
		print "Could not read line from "+ab_sequence_file+": "+line
		pass

# Perform sanity check to make sure that user gave the correct input
for abName in input_dict:	
	VL = input_dict[abName]['lightChain']
        VH = input_dict[abName]['heavyChain']
        chainType = input_dict[abName]['lightChainType']
	allSegmentEndingsAreCanonical = True
        find_segments.input_sanity_check( VL , VH , chainType , allSegmentEndingsAreCanonical )
	

# Read in torsion databases
torsion_db_dict = {'lambda':{}, 'kappa':{}}
torsion_db_dict['lambda'] = find_segments.read_torsion_db_files( lambda_config_dir )
torsion_db_dict['kappa'] = find_segments.read_torsion_db_files( kappa_config_dir )

# Clean up before working

##############################################
#               Submit jobs
# allq_sub.sh is system specific and should
# contain the setup for submitting jobs to 
# the queueing system. If running only one 
# job you can replace that with 
# rosetta_scripts.default.linuxgccrelease
#############################################
for abName in input_dict.keys():
	print ""
	print abName
	chainType = input_dict[abName]['lightChainType']
	VL = input_dict[abName]['lightChain']
        VH = input_dict[abName]['heavyChain']	
	
	# Set paths for rosetta
	if chainType == 'lambda':
		# I'm here doing a benchmark, so I'm using special unbiased torsion databases.
		#configdir='/home/labs/fleishman/norn/config_dirs/2G75_config_dir'
		#source_pdb='/home/labs/fleishman/norn/config_dirs/2G75_config_dir/2G75.ppk.pdb'
		configdir=lambda_config_dir
		source_pdb=lambda_config_dir+'2G75.ppk.pdb'
		template_pdb=lambda_config_dir+'2G75.ppk.pdb'	
		#continue # THIS SHOULD PROBABLY NOT BE DONE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	elif chainType == 'kappa':
		configdir=kappa_config_dir
		source_pdb=kappa_config_dir+'2BRR.ppk.pdb'
		template_pdb=kappa_config_dir+'2BRR.ppk.pdb'	
		#continue
	# Select random segments of correct length from database to seed the prediction trajectory
        (vl_n_tail_len, vl_CDR1_CDR2_len, vl_CDR3_c_tail_len) = find_segments.determine_segment_lengths(VL)
        (vh_n_tail_len, vh_CDR1_CDR2_len, vh_CDR3_c_tail_len) = find_segments.determine_segment_lengths(VH)
	
	# Generate the job scripts for the cluster and randomly select segments for every job
	vH_list, H3_list, vL_list, L3_list = find_segments.output_segment_info(torsion_db_dict[chainType],vl_CDR1_CDR2_len,vl_CDR3_c_tail_len,vh_CDR1_CDR2_len,vh_CDR3_c_tail_len,abName,'returnAllIn4Lists',chainType)
	print "vH "+str(len(vH_list))
	print "H3 "+str(len(H3_list))
	print "vL "+str(len(vL_list))
	print "L3 "+str(len(L3_list)) 

# shuffle the jobs, so we will get outputs from all targets as they finish
#os.system("cat command | perl -MList::Util=shuffle -e 'print shuffle(<STDIN>);' > tmp2") 
#os.system("mv tmp2 command")	

# Submit to cluster
#os.system('chmod +x command')
#os.system('./command')
