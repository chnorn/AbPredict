The lowest energy members of the three most populated clusters resulting from an AbPredict simulation generating 3000 structures, is located here.

Benchmark_target	cluster_rank	pdb_id
4M43  				1 				4M43_759_2BRR.ppk_0001.pdb 
4M43  				2 				4M43_2413_2BRR.ppk_0001.pdb
4M43  				3 				4M43_2172_2BRR.ppk_0001.pdb
4M7K  				1 				4M7K_1306_2BRR.ppk_0001.pdb 
4M7K  				2 				4M7K_590_2BRR.ppk_0001.pdb 
4M7K  				3 				4M7K_181_2BRR.ppk_0001.pdb 
4M6M  				1 				4M6M_5818_2G75.ppk_0001.pdb
4M6M  				2 				4M6M_5708_2G75.ppk_0001.pdb
4M6M  				3 				4M6M_4221_2G75.ppk_0001.pdb
4MAU  				1 				4MAU_2091_2BRR.ppk_0001.pdb 
4MAU  				2 				4MAU_292_2BRR.ppk_0001.pdb 
4MAU  				3 				4MAU_2782_2BRR.ppk_0001.pdb
4KMT  				1 				4KMT_2309_2BRR.ppk_0001.pdb
4KMT  				2 				4KMT_760_2BRR.ppk_0001.pdb 
4KMT  				3 				4KMT_424_2BRR.ppk_0001.pdb 
4KQ3  				1 				4KQ3_1769_2BRR.ppk_0001.pdb
4KQ3  				2 				4KQ3_2992_2BRR.ppk_0001.pdb
4KQ3  				3 				4KQ3_38_2BRR.ppk_0001.pdb 
4KQ4  				1 				4KQ4_160_2BRR.ppk_0001.pdb 
4KQ4  				2 				4KQ4_2556_2BRR.ppk_0001.pdb
4KQ4  				3 				4KQ4_245_2BRR.ppk_0001.pdb 
4M61  				1 				4M61_2350_2BRR.ppk_0001.pdb
4M61  				2 				4M61_2065_2BRR.ppk_0001.pdb
4M61  				3 				4M61_1988_2BRR.ppk_0001.pdb
